import test from "node:test";
import { BINARY_SUDOKU_TESTS } from "../src/test-cases.js";

for (const testCase of BINARY_SUDOKU_TESTS) {
  test(testCase.title, () => testCase.run());
}
