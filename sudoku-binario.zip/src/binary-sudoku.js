export const SIZE = 6;
export const SYMBOLS_PER_LINE = SIZE / 2;

export function createEmptyBoard() {
  return Array.from({ length: SIZE }, () => Array(SIZE).fill(null));
}

function addError(errors, code, message, row = null, column = null) {
  errors.push({ code, message, row, column });
}

function hasTriple(line) {
  for (let index = 0; index <= line.length - 3; index += 1) {
    const first = line[index];
    if (first !== null && first !== undefined && first === line[index + 1] && first === line[index + 2]) {
      return index;
    }
  }
  return -1;
}

function completedLine(line) {
  return line.every((value) => value === 0 || value === 1);
}

function lineKey(line) {
  return line.join("");
}

/**
 * Valida um tabuleiro Binário 6×6.
 * allowIncomplete=true valida restrições incrementais em tabuleiros com casas null;
 * allowIncomplete=false exige uma solução completa e válida.
 */
export function validateBoard(board, { allowIncomplete = false } = {}) {
  const errors = [];
  if (!Array.isArray(board) || board.length !== SIZE || board.some((row) => !Array.isArray(row) || row.length !== SIZE)) {
    addError(errors, "invalid-shape", `O tabuleiro deve ter exatamente ${SIZE} linhas e ${SIZE} colunas.`);
    return { valid: false, complete: false, errors };
  }

  for (let row = 0; row < SIZE; row += 1) {
    for (let column = 0; column < SIZE; column += 1) {
      const value = board[row][column];
      if (value !== null && value !== 0 && value !== 1) {
        addError(errors, "invalid-value", "Cada casa deve conter 0, 1 ou null.", row, column);
      }
    }
  }
  if (errors.length > 0) return { valid: false, complete: false, errors };

  const lines = [];
  for (let row = 0; row < SIZE; row += 1) {
    lines.push({ type: "row", index: row, values: board[row] });
  }
  for (let column = 0; column < SIZE; column += 1) {
    lines.push({
      type: "column",
      index: column,
      values: board.map((row) => row[column]),
    });
  }

  for (const line of lines) {
    const { type, index, values } = line;
    const zeroCount = values.filter((value) => value === 0).length;
    const oneCount = values.filter((value) => value === 1).length;
    const label = type === "row" ? `linha ${index + 1}` : `coluna ${index + 1}`;

    if (zeroCount > SYMBOLS_PER_LINE || oneCount > SYMBOLS_PER_LINE) {
      addError(errors, "too-many-symbols", `A ${label} não pode ter mais de três zeros nem mais de três uns.`, type === "row" ? index : null, type === "column" ? index : null);
    }

    const tripleAt = hasTriple(values);
    if (tripleAt !== -1) {
      addError(errors, "three-consecutive", `A ${label} tem três símbolos iguais consecutivos.`, type === "row" ? index : null, type === "column" ? index : null);
    }

    if (completedLine(values) && (zeroCount !== SYMBOLS_PER_LINE || oneCount !== SYMBOLS_PER_LINE)) {
      addError(errors, "unbalanced-line", `A ${label} completa deve conter exatamente três zeros e três uns.`, type === "row" ? index : null, type === "column" ? index : null);
    }
  }

  for (const type of ["row", "column"]) {
    const seen = new Map();
    for (let index = 0; index < SIZE; index += 1) {
      const values = type === "row" ? board[index] : board.map((row) => row[index]);
      if (!completedLine(values)) continue;
      const key = lineKey(values);
      if (seen.has(key)) {
        const label = type === "row" ? "linhas" : "colunas";
        addError(errors, "duplicate-line", `As ${label} ${seen.get(key) + 1} e ${index + 1} são iguais.`, type === "row" ? index : null, type === "column" ? index : null);
      } else {
        seen.set(key, index);
      }
    }
  }

  const complete = board.every((row) => completedLine(row));
  if (!allowIncomplete && !complete) {
    addError(errors, "incomplete-board", "O tabuleiro deve estar completamente preenchido.");
  }

  return { valid: errors.length === 0, complete, errors };
}

export function isValidSolution(board) {
  return validateBoard(board).valid;
}
