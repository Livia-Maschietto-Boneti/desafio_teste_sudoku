import { createEmptyBoard, isValidSolution, validateBoard } from "./binary-sudoku.js";

export const VALID_SOLUTION = [
  [0, 0, 1, 0, 1, 1],
  [0, 0, 1, 1, 0, 1],
  [1, 1, 0, 0, 1, 0],
  [0, 1, 0, 0, 1, 1],
  [1, 0, 1, 1, 0, 0],
  [1, 1, 0, 1, 0, 0],
];

function cloneBoard(board) {
  return board.map((row) => [...row]);
}

function expect(condition, message) {
  if (!condition) throw new Error(message);
}

function hasCode(result, code) {
  return result.errors.some((error) => error.code === code);
}

export const BINARY_SUDOKU_TESTS = [
  {
    id: "empty-board-size",
    title: "Cria tabuleiro vazio 6 × 6",
    run() {
      const board = createEmptyBoard();
      expect(board.length === 6 && board.every((row) => row.length === 6), "O tabuleiro deve ter seis linhas e seis colunas.");
      expect(board.flat().every((cell) => cell === null), "Todas as casas devem começar vazias.");
      expect(new Set(board.flat()).size === 1, "Cada valor inicial deve ser null.");
    },
  },
  {
    id: "valid-solution",
    title: "Aceita uma solução completa válida",
    run() {
      const result = validateBoard(VALID_SOLUTION);
      expect(result.valid && result.complete, "A grade válida deve ser aceita como solução completa.");
      expect(isValidSolution(VALID_SOLUTION), "isValidSolution deve reconhecer a solução correta.");
    },
  },
  {
    id: "row-balance",
    title: "Exige três zeros e três uns em cada linha",
    run() {
      const board = cloneBoard(VALID_SOLUTION);
      board[0] = [0, 0, 0, 1, 1, 1];
      expect(hasCode(validateBoard(board), "three-consecutive"), "Três zeros seguidos na linha devem ser rejeitados.");
    },
  },
  {
    id: "column-balance",
    title: "Exige três zeros e três uns em cada coluna",
    run() {
      const board = cloneBoard(VALID_SOLUTION);
      for (let row = 0; row < 6; row += 1) board[row][0] = 0;
      const result = validateBoard(board);
      expect(hasCode(result, "too-many-symbols") || hasCode(result, "three-consecutive"), "Uma coluna desequilibrada deve ser rejeitada.");
    },
  },
  {
    id: "no-three-in-row",
    title: "Proíbe três símbolos iguais consecutivos na horizontal",
    run() {
      const board = cloneBoard(VALID_SOLUTION);
      board[0] = [0, 0, 0, 1, 1, 1];
      expect(hasCode(validateBoard(board), "three-consecutive"), "Três símbolos iguais consecutivos na linha devem ser detectados.");
    },
  },
  {
    id: "no-three-in-column",
    title: "Proíbe três símbolos iguais consecutivos na vertical",
    run() {
      const board = cloneBoard(VALID_SOLUTION);
      board[0][0] = 1;
      board[1][0] = 1;
      board[2][0] = 1;
      expect(hasCode(validateBoard(board), "three-consecutive"), "Três símbolos iguais consecutivos na coluna devem ser detectados.");
    },
  },
  {
    id: "unique-rows",
    title: "Proíbe linhas completas duplicadas",
    run() {
      const board = cloneBoard(VALID_SOLUTION);
      board[1] = [...board[0]];
      expect(hasCode(validateBoard(board), "duplicate-line"), "Linhas completas iguais devem ser rejeitadas.");
    },
  },
  {
    id: "unique-columns",
    title: "Proíbe colunas completas duplicadas",
    run() {
      const board = cloneBoard(VALID_SOLUTION);
      for (let row = 0; row < 6; row += 1) board[row][1] = board[row][0];
      expect(hasCode(validateBoard(board), "duplicate-line"), "Colunas completas iguais devem ser rejeitadas.");
    },
  },
  {
    id: "invalid-symbol",
    title: "Rejeita símbolo diferente de zero, um ou vazio",
    run() {
      const board = cloneBoard(VALID_SOLUTION);
      board[2][3] = 2;
      expect(hasCode(validateBoard(board), "invalid-value"), "O valor 2 não é permitido.");
    },
  },
  {
    id: "invalid-shape",
    title: "Rejeita tabuleiro com dimensão incorreta",
    run() {
      const result = validateBoard(Array.from({ length: 5 }, () => Array(6).fill(null)), { allowIncomplete: true });
      expect(!result.valid && hasCode(result, "invalid-shape"), "Um tabuleiro 5 × 6 deve ser rejeitado.");
    },
  },
  {
    id: "incomplete-rejected-as-solution",
    title: "Rejeita casas vazias em solução completa",
    run() {
      const board = cloneBoard(VALID_SOLUTION);
      board[0][0] = null;
      const result = validateBoard(board);
      expect(!result.valid && !result.complete && hasCode(result, "incomplete-board"), "Uma solução final não pode ter casas vazias.");
    },
  },
  {
    id: "partial-board-allowed",
    title: "Aceita tabuleiro parcial sem conflitos imediatos",
    run() {
      const board = createEmptyBoard();
      board[0] = [0, 1, 0, 1, null, null];
      const result = validateBoard(board, { allowIncomplete: true });
      expect(result.valid && !result.complete, "Um estado parcial consistente deve ser permitido durante o jogo.");
    },
  },
  {
    id: "partial-count-overflow",
    title: "Rejeita excesso de um mesmo símbolo em linha parcial",
    run() {
      const board = createEmptyBoard();
      board[0] = [0, 0, 0, 0, null, null];
      const result = validateBoard(board, { allowIncomplete: true });
      expect(hasCode(result, "too-many-symbols"), "Uma linha parcial não pode conter quatro zeros.");
    },
  },
  {
    id: "independent-board-rows",
    title: "Cria linhas independentes para tabuleiros separados",
    run() {
      const first = createEmptyBoard();
      const second = createEmptyBoard();
      first[0][0] = 1;
      expect(second[0][0] === null, "Alterar um tabuleiro não pode modificar outro.");
      expect(first[0] !== first[1], "Linhas distintas não devem compartilhar a mesma referência.");
    },
  },
];
